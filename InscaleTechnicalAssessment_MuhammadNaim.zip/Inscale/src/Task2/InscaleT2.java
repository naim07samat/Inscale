package Task2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class InscaleT2 {

	public static void main(String[] args) throws InterruptedException
	{
		//open browser
		System.setProperty("webdriver.chrome.driver", "C:\\browserdriver\\chromedriver.exe");		
		ChromeDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				
		//open link site
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
		driver.manage().window().maximize();
				
		//checking open correct site
		String bankTitle=" ";
		bankTitle = driver.findElement(By.xpath("//div/strong[@class='mainHeading']")).getText();
		if(bankTitle.equalsIgnoreCase("XYZ Bank"))
			System.out.println("Logged into XYZ Bank");
		else
			System.out.println(bankTitle);
		Thread.sleep(3000);
		
		//manager login
		WebElement customerLogin = driver.findElement(By.xpath("//div/button[contains(., 'Customer Login')]"));
		customerLogin.click();
		Thread.sleep(3000);
		
		//slide dropdown selection
		WebElement select = driver.findElement(By.xpath("//div/select[@id = 'userSelect']"));
		select.click();
		Thread.sleep(3000);
		
		//select Hermoine
		WebElement hermoine = driver.findElement(By.xpath("//div/select/option[@value='1']"));
		hermoine.click();
		System.out.println("Customer logged in as Hermoine");
		Thread.sleep(3000);
		
		//click Login
		WebElement login = driver.findElement(By.xpath("//div/form/button"));
		login.click();
		Thread.sleep(3000);
		
		//select account number 1003
		WebElement accNo = driver.findElement(By.xpath("//div/select[@id='accountSelect']"));
		accNo.click();
		WebElement acc1003 = driver.findElement(By.xpath("//div/select/option[@label='1003']"));
		acc1003.click();
		Thread.sleep(3000);
		
		//checking balance = 0
		String accStatement = driver.findElement(By.xpath("//div[@class='center']")).getText();
		System.out.println("Account statement for current user. " + accStatement);
		String accBal = driver.findElement(By.xpath("//div[2]/strong[2]")).getText();
		
		if(accBal.equals("0"))
			System.out.println("Account balance is equal to 0");
		else
			System.out.println("Account balance is not equal to 0");
		
		//define deposit and withdrawal
		WebElement deposit = driver.findElement(By.xpath("//div[3]/button[2]"));
		WebElement withdraw = driver.findElement(By.xpath("//div[3]/button[3]"));
		String[] transaction = {"Credit", "Debit", "Debit", "Credit", "Debit", "Debit", "Credit"};
		int[] amount = {50000, 3000, 2000, 5000, 10000, 15000, 1500};
		
		//initial current balance
		int currBal = 0;
		
		//transaction process
		for (int i=0; i<transaction.length; i++) {
			if (transaction[i] == "Credit"){
				deposit.click();
				WebElement depo = driver.findElement(By.xpath("//form[@ng-submit='deposit()']/div/input"));
				
				//input amount and complete transaction
				String amTx = amount[i] + " ";
				depo.sendKeys(amTx);
				WebElement depoBtn = driver.findElement(By.xpath("//form[@ng-submit='deposit()']/button"));
				depoBtn.click();
				
				//successful message
				String status = " ";
				status = driver.findElement(By.xpath("//div[4]/div/span")).getText();
				if (status.equalsIgnoreCase("Deposit Successful"))
					System.out.println("Deposit transaction is passed.");
				else 
					System.out.println("Deposit transaction is failed.");
				
				//credit == deposit == add currBal
				currBal = currBal + amount[i];
				
				//verify current balance in statement tally with calculation
				accBal = driver.findElement(By.xpath("//div[2]/strong[2]")).getText();
				int accBalance = Integer.parseInt(accBal);
				if (accBalance == currBal)
					System.out.println("New account balance is: " + currBal + " after "
					+ transaction[i] + "ed amount " + amount[i]);
				else
					System.out.println("Calculation is not tally");

				Thread.sleep(3000);
				
			}
			else if (transaction[i] == "Debit") {
				withdraw.click();
				WebElement withdr = driver.findElement(By.xpath("//form[@ng-submit='withdrawl()']/div/input"));
				
				//input amount and complete transaction
				String amTx = amount[i] + " ";
				withdr.sendKeys(amTx);
				WebElement withdrBtn = driver.findElement(By.xpath("//form[@ng-submit='withdrawl()']/button"));
				withdrBtn.click();
				
				//successful message
				String status = " ";
				status = driver.findElement(By.xpath("//div[4]/div/span")).getText();
				if (status.equalsIgnoreCase("Transaction successful"))
					System.out.println("Withdrawal transaction is passed.");
				else 
					System.out.println("Withdrawal transaction is failed.");
				
				//credit == deposit == minus currBal
				currBal = currBal - amount[i];
				
				//verify current balance in statement tally with calculation
				accBal = driver.findElement(By.xpath("//div[2]/strong[2]")).getText();
				int accBalance = Integer.parseInt(accBal);
				if (accBalance == currBal)
					System.out.println("New account balance is: " + currBal + " after " 
					+ transaction[i] + "ed amount " + amount[i]);
				else
					System.out.println("Calculation is not tally");
				
				Thread.sleep(3000);
				
			}	
		};
		
		//verify final calculation tally with final balance
		accBal = driver.findElement(By.xpath("//div[2]/strong[2]")).getText();
		int accBalance = Integer.parseInt(accBal);
		if (accBalance == currBal)
			System.out.println("Transaction completed with current balance: " + currBal);
		else
			System.out.println("Calculation is not tally");
		
		driver.close();
		
	}
	
}
