package Task1;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoAlertPresentException;	
import org.openqa.selenium.Alert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class InscaleT1 {

	public static void main(String[] args) throws NoAlertPresentException,InterruptedException
	{
		//open browser
		System.setProperty("webdriver.chrome.driver", "C:\\browserdriver\\chromedriver.exe");		
		ChromeDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
		//open link site
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
		driver.manage().window().maximize();
		
		//checking open correct site
		String bankTitle=" ";
		bankTitle = driver.findElement(By.xpath("//div/strong[@class='mainHeading']")).getText();
		if(bankTitle.equalsIgnoreCase("XYZ Bank"))
			System.out.println("Logged into XYZ Bank");
		else
			System.out.println(bankTitle);
		Thread.sleep(3000);
		
		//manager login
		WebElement managerLogin = driver.findElement(By.xpath("//div/button[contains(., 'Bank Manager Login')]"));
		managerLogin.click();
		System.out.println("User Log In as Bank Manager");
		Thread.sleep(3000);
		
		//add customer
		WebElement addCustomer = driver.findElement(By.xpath("//div/button[@ng-class ='btnClass1']"));
		addCustomer.click();
		
		//identify element
		WebElement firstName = driver.findElement(By.xpath("//div/input[@placeholder ='First Name']"));
		WebElement lastName = driver.findElement(By.xpath("//div/input[@placeholder ='Last Name']"));
		WebElement postCode = driver.findElement(By.xpath("//div/input[@placeholder ='Post Code']"));
		WebElement submit = driver.findElement(By.xpath("//div/form/button"));
		
		//define customer details
		String[][] customer = {
				{"Christopher","Connely","L789C349"},
				{"Frank","Christopher","A897N450"},
				{"Christopher","Minka","M098Q585"},
				{"Connely","Jackson","L789C349"},
				{"Jackson","Frank","L789C349"},
				{"Minka","Jackson","A897N450"},
				{"Jackson","Connely","L789C349"},
				{"Lawrence","Zimmerman","L789C349"},
				{"Mariotte","Tova","L789C349"}				
		};
		
		String totalStr = " ";
		int totalAdd = 0;
		
		//manipulate array
		for (int i=0; i<customer.length; ++i) {
		System.out.println("firstname " + customer[i][0]);
		System.out.println("lastname " + customer[i][1]);
		System.out.println("postcode " + customer[i][2]);
		
		//input customer details
		firstName.sendKeys(customer[i][0]);
		lastName.sendKeys(customer[i][1]);
		postCode.sendKeys(customer[i][2]);
		Thread.sleep(5000);
		submit.click();
		
		//handling browser alert
		Alert alert = driver.switchTo().alert();
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		Thread.sleep(5000);
		alert.accept();
		totalStr = alertMessage.substring(46);
		totalAdd = totalAdd+1;
		}
		
		//switch to customer tab
		WebElement customerTab = driver.findElement(By.xpath("//div/button[@ng-class='btnClass3']"));
		customerTab.click();
		Thread.sleep(5000);
		
		//counting added list
		System.out.println("Count total column : " + totalStr);
		int totalEx = Integer.parseInt(totalStr)-totalAdd;
		System.out.println("Total existing lists: " + totalEx);
		System.out.println("Total added lists: " + totalAdd);
		
		//finding specified customer to be delete from list no10 and no6
		WebElement line10 = driver.findElement(By.xpath("//div/table/tbody/tr[10]/td/button"));
		line10.click();
		Thread.sleep(5000);
		System.out.println("Deleted Line 10: Jackson Frank L789C349");
		WebElement line6 = driver.findElement(By.xpath("//div/table/tbody/tr[6]/td/button"));
		line6.click();
		System.out.println("Deleted Line 6: Christopher Connely L789C349");
		Thread.sleep(5000);
		
		driver.close();

	}

}
