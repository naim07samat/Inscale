===============================BEGIN========================================

*You are about to access Inscale Technical Assessment files.
*Conducted using Eclipse.
*Using extension jdk-19 version and selenium-server-4.7.2
*Using Java language.
*Consists of 2 projects for 2 individual tasks.
*Prepared by Muhammad Na'im bin Samat.









===============================END==========================================
